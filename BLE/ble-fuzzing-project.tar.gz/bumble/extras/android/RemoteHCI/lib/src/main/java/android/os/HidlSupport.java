package android.os;

public class HidlSupport {
    public static boolean interfacesEqual(IHwInterface lft, Object rgt) {
        return false; // STUB
    }
    public static native int getPidIfSharable();
}
