package android.os;

public final class ServiceManager {
    public static IBinder getService(String name) {
        return null; // Stub
    }
}